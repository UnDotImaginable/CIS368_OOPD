import to_use.*;

public class Test_class {
    public static void main(String[] args) throws Exception {
	System.out.println("Lab 1 Start__________________");
        Name veerg = new Name("Veer", "S", "Gaudani");
        Address veerg_Address = new Address(12345, "Merry Drive", "", "Garyville", "OH", "44881");
        PhoneList veerg_phonelist = new PhoneList();

        PersonInfo vg_p1 = new PersonInfo(veerg, veerg_Address, veerg_phonelist);
        vg_p1.addNewNumber("216", "334", "3813");

        System.out.println(vg_p1.getName());
        System.out.println(vg_p1.getAddress());
        vg_p1.showPhoneList();
//LAB 2 ADDITIONS
	System.out.println();
	System.out.println();
	System.out.println("Lab 2 Start__________________");
	//Course algebra = new Course("linear  ...+    algebra", "MATH", "two88", "8seven");
	Course algebra = new Course("linear algebra", "mth", "288", "87.4");
	//System.out.println(algebra);
	//StudentRecord student = new StudentRecord("123", vg_p1);
	StudentRecord student = new StudentRecord("9999999", vg_p1);
	student.addCourse(algebra);
	//System.out.println(student.toString());
	System.out.println(student);
        
    }
}
