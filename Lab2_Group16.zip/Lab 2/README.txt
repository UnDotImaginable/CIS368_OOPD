README

Group 16

To test lab 2, when inside lab 2 directory run
>java Test_class.java

Output for Lab 1 and Lab 2 are seperated, Test_class.java has commented out lines with false input to check error handling, you can swap out correct input and errored input by swapping arguments. Not all methods of each class are tested, we only used toString(), initialization, and addCourse() methods for testing because those are all thats relevant for this lab. Methods run through ->Course() or through ->studentRecord()->Transcript()